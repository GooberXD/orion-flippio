package FileManager;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Per-teacher subject summary CSV.
 * Format per line: <Subject ID>|<Subject Name>|<Number of Student Enrolled>
 */
public class TeacherSubjectSummaryFileManager {
    private final File file;

    public TeacherSubjectSummaryFileManager(String teacherId) {
        this.file = new File("subject_" + teacherId + ".csv");
    }

    public List<String[]> readAll() throws IOException {
        List<String[]> rows = new ArrayList<>();
        if (!file.exists()) return rows;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|", -1);
                rows.add(parts);
            }
        }
        return rows;
    }

    public void writeAll(List<String[]> rows) throws IOException {
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, false), StandardCharsets.UTF_8))) {
            for (String[] r : rows) {
                String id = safe(r,0), name = safe(r,1), count = safe(r,2);
                bw.write(String.join("|", id, name, count));
                bw.newLine();
            }
        }
    }

    private String safe(String[] a, int i){ return (a!=null && a.length>i && a[i]!=null) ? a[i] : ""; }
}
