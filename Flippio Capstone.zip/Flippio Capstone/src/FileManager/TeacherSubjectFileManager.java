package FileManager;

import Exception.FileReadException;
import Exception.FileWriteException;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Manages teacher-scoped subjects in a single file: teacher_<teacherId>.csv
 * Format: subjectId|subjectName|studentId1,studentId2,studentId3
 */
public class TeacherSubjectFileManager {
    private final File file;
    private final String teacherId;

    public TeacherSubjectFileManager(String teacherId) {
        this.teacherId = teacherId;
        this.file = new File("teacher_" + teacherId + ".csv");
    }

    /**
     * Load all subjects for this teacher
     * @return Map of subjectId -> SubjectData
     */
    public Map<String, SubjectData> loadAllSubjects() throws FileReadException {
        Map<String, SubjectData> subjects = new LinkedHashMap<>();
        if (!file.exists()) return subjects;
        
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                
                String[] parts = line.split("\\|", 3);
                if (parts.length >= 2) {
                    String subjectId = parts[0];
                    String subjectName = parts[1];
                    List<String> studentIds = new ArrayList<>();
                    
                    if (parts.length >= 3 && !parts[2].trim().isEmpty()) {
                        String[] ids = parts[2].split(",");
                        for (String id : ids) {
                            String trimmed = id.trim();
                            if (!trimmed.isEmpty()) {
                                studentIds.add(trimmed);
                            }
                        }
                    }
                    
                    subjects.put(subjectId, new SubjectData(subjectId, subjectName, studentIds));
                }
            }
            return subjects;
        } catch (IOException e) {
            throw new FileReadException("Failed to read teacher subjects: " + file.getAbsolutePath());
        }
    }

    /**
     * Get specific subject data
     */
    public SubjectData getSubject(String subjectId) throws FileReadException {
        return loadAllSubjects().get(subjectId);
    }

    /**
     * Create or update a subject
     */
    public void saveSubject(String subjectId, String subjectName, List<String> studentIds) throws FileReadException, FileWriteException {
        Map<String, SubjectData> subjects = loadAllSubjects();
        subjects.put(subjectId, new SubjectData(subjectId, subjectName, studentIds));
        saveAll(subjects);
    }

    /**
     * Add student to a subject
     */
    public void addStudentToSubject(String subjectId, String studentId) throws FileReadException, FileWriteException {
        Map<String, SubjectData> subjects = loadAllSubjects();
        SubjectData subject = subjects.get(subjectId);
        if (subject == null) {
            throw new FileReadException("Subject " + subjectId + " not found for teacher " + teacherId);
        }
        
        if (!subject.studentIds.contains(studentId)) {
            subject.studentIds.add(studentId);
            saveAll(subjects);
        }
    }

    /**
     * Remove student from a subject
     */
    public void removeStudentFromSubject(String subjectId, String studentId) throws FileReadException, FileWriteException {
        Map<String, SubjectData> subjects = loadAllSubjects();
        SubjectData subject = subjects.get(subjectId);
        if (subject != null) {
            subject.studentIds.remove(studentId);
            saveAll(subjects);
        }
    }

    /**
     * Delete a subject
     */
    public void deleteSubject(String subjectId) throws FileReadException, FileWriteException {
        Map<String, SubjectData> subjects = loadAllSubjects();
        subjects.remove(subjectId);
        saveAll(subjects);
    }

    /**
     * Check if subject exists for this teacher
     */
    public boolean subjectExists(String subjectId) throws FileReadException {
        return loadAllSubjects().containsKey(subjectId);
    }

    private void saveAll(Map<String, SubjectData> subjects) throws FileWriteException {
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            
            try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, false), StandardCharsets.UTF_8))) {
                for (SubjectData subject : subjects.values()) {
                    bw.write(subject.subjectId);
                    bw.write("|");
                    bw.write(subject.subjectName);
                    bw.write("|");
                    bw.write(String.join(",", subject.studentIds));
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            throw new FileWriteException("Failed to write teacher subjects: " + file.getAbsolutePath());
        }
    }

    /**
     * Data class to hold subject information
     */
    public static class SubjectData {
        public final String subjectId;
        public final String subjectName;
        public final List<String> studentIds;

        public SubjectData(String subjectId, String subjectName, List<String> studentIds) {
            this.subjectId = subjectId;
            this.subjectName = subjectName;
            this.studentIds = new ArrayList<>(studentIds);
        }

        public int getStudentCount() {
            return studentIds.size();
        }
    }
}
