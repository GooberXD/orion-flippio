package View;

import Model.Subject;
import Utility.FontUtil;
import Utility.ResourceLoader;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

public class TeacherSubjectDashboardView extends JFrame {
    private JLabel titleLabel;
    private final DefaultTableModel subjectTableModel = new DefaultTableModel(new String[]{"Subject ID", "Name"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable subjectTable = new JTable(subjectTableModel);
    private final JTextField idField = new JTextField();
    private final JTextField nameField = new JTextField();
    private Consumer2 onAdd;
    private Consumer<Subject> onRemove;
    private Consumer<Subject> onOpen;

    public TeacherSubjectDashboardView() {
        super("Teacher Subject Dashboard");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // Flexible fullscreen across displays
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setResizable(true);
        setLocationRelativeTo(null);

        // Window Icon aligned with TeacherDashboard
        ImageIcon appIcon = ResourceLoader.loadImageIcon("Logo.png");
        if (appIcon == null) appIcon = ResourceLoader.loadImageIcon("Prototype Design.png");
        if (appIcon != null) setIconImage(appIcon.getImage());

        JPanel root = new JPanel(new BorderLayout());

        // Top panel styling similar to other dashboards
        JPanel topPanel = new JPanel(new GridBagLayout());
        topPanel.setBackground(Color.decode("#9146FF"));
        topPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        titleLabel = new JLabel("Hi Teacher _!");
        titleLabel.setFont(FontUtil.montserrat(20f, Font.BOLD, new Font("Arial", Font.BOLD, 20)));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setVerticalAlignment(SwingConstants.CENTER);
        // Center logo
        JLabel logo = new JLabel();
        ImageIcon headerLogo = ResourceLoader.loadImageIcon("Prototype Design.png");
        if (headerLogo == null) headerLogo = ResourceLoader.loadImageIcon("Prototype Design.jpg");
        if (headerLogo != null) {
            java.awt.Image scaled = headerLogo.getImage().getScaledInstance(200, 80, java.awt.Image.SCALE_SMOOTH);
            logo.setIcon(new ImageIcon(scaled));
        }
        logo.setHorizontalAlignment(SwingConstants.CENTER);
        // Logout button on right (match sizing)
        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(FontUtil.montserrat(12f, Font.BOLD, new Font("Arial", Font.BOLD, 12)));
        logoutButton.setPreferredSize(new Dimension(100, 32));
        JPanel rightButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightButtons.setOpaque(false);
        rightButtons.add(logoutButton);

        // Lay out with GridBagLayout to align vertically centered
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridy = 0; gbc.insets = new Insets(0,0,0,0); gbc.fill = GridBagConstraints.NONE;

        // Left: Title
        gbc.gridx = 0; gbc.weightx = 0; gbc.anchor = GridBagConstraints.WEST;
        topPanel.add(titleLabel, gbc);

        // Center: Logo (grows to take remaining space to keep centered)
        gbc.gridx = 1; gbc.weightx = 1; gbc.anchor = GridBagConstraints.CENTER;
        topPanel.add(logo, gbc);

        // Right: Logout
        gbc.gridx = 2; gbc.weightx = 0; gbc.anchor = GridBagConstraints.EAST;
        topPanel.add(rightButtons, gbc);
        root.add(topPanel, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(10,10));
        center.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        subjectTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        subjectTable.setRowHeight(22);
        subjectTable.setFont(FontUtil.montserrat(12f, Font.PLAIN, subjectTable.getFont()));
        subjectTable.getTableHeader().setFont(FontUtil.montserrat(12f, Font.BOLD, subjectTable.getTableHeader().getFont()));
        center.add(new JScrollPane(subjectTable), BorderLayout.CENTER);

        JPanel form = new JPanel(new GridLayout(0,2,8,8));
        form.add(new JLabel("Subject ID:"));
        form.add(idField);
        form.add(new JLabel("Name:"));
        form.add(nameField);

        JButton addBtn = new JButton("Add Subject");
        JButton removeBtn = new JButton("Remove Selected");
        JButton openBtn = new JButton("Open Subject");
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.add(addBtn);
        actions.add(removeBtn);
        actions.add(openBtn);

        JPanel south = new JPanel(new BorderLayout());
        south.add(form, BorderLayout.CENTER);
        south.add(actions, BorderLayout.SOUTH);
        center.add(south, BorderLayout.SOUTH);
        root.add(center, BorderLayout.CENTER);

        addBtn.addActionListener(e -> {
            if (onAdd != null) {
                onAdd.accept(idField.getText().trim(), nameField.getText().trim());
                idField.setText("");
                nameField.setText("");
            }
        });

        removeBtn.addActionListener(e -> {
            if (onRemove != null) {
                Subject s = getSelectedSubject();
                onRemove.accept(s);
            }
        });

        openBtn.addActionListener(e -> {
            if (onOpen != null) {
                Subject s = getSelectedSubject();
                onOpen.accept(s);
            }
        });

        subjectTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2 && onOpen != null) {
                    Subject s = getSelectedSubject();
                    onOpen.accept(s);
                }
            }
        });

        setContentPane(root);

        // Expose logout button via client property for controller
        this.getRootPane().putClientProperty("logoutButton", logoutButton);
    }

    public void setSubjects(List<Subject> subjects) {
        subjectTableModel.setRowCount(0);
        for (Subject s : subjects) subjectTableModel.addRow(new Object[]{s.getId(), s.getName()});
    }

    public void setTeacherGreeting(String teacherName) {
        if (teacherName == null || teacherName.trim().isEmpty()) {
            titleLabel.setText("Hi Teacher _!");
        } else {
            titleLabel.setText("Hi " + teacherName + "!");
        }
    }

    private Subject getSelectedSubject() {
        int row = subjectTable.getSelectedRow();
        if (row < 0) return null;
        String id = (String) subjectTableModel.getValueAt(row, 0);
        String name = (String) subjectTableModel.getValueAt(row, 1);
        return new Subject(id, name, null);
    }

    public void onAddSubject(Consumer2 addHandler) { this.onAdd = addHandler; }
    public void onRemoveSubject(Consumer<Subject> removeHandler) { this.onRemove = removeHandler; }
    public void onOpenSubject(Consumer<Subject> openHandler) { this.onOpen = openHandler; }
    public void addLogoutListener(java.awt.event.ActionListener listener) {
        Object btn = this.getRootPane().getClientProperty("logoutButton");
        if (btn instanceof JButton) {
            ((JButton) btn).addActionListener(listener);
        }
    }

    public void showError(String message) { JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE); }

    @FunctionalInterface
    public interface Consumer2 {
        void accept(String id, String name);
    }
}
