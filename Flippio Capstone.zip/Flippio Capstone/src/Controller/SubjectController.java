package Controller;

import FileManager.SubjectFileManager;
import Model.Subject;
import View.TeacherSubjectDashboardView;
import Exception.FileReadException;

import java.util.ArrayList;
import java.util.List;

public class SubjectController {
    private final SubjectFileManager fileManager;
    private final TeacherSubjectDashboardView view;
    private List<Subject> subjects = new ArrayList<>();

    private Model.Teacher teacher;

    public SubjectController(SubjectFileManager fileManager, TeacherSubjectDashboardView view) {
        this.fileManager = fileManager;
        this.view = view;
        this.view.onAddSubject(this::addSubject);
        this.view.onRemoveSubject(this::removeSelectedSubject);
        this.view.onOpenSubject(this::openSubjectDashboard);
        loadSubjects();
    }

    private void loadSubjects() {
        try {
            subjects = fileManager.readAll();
            view.setSubjects(subjects);
        } catch (FileReadException e) {
            view.showError("Failed to load subjects: " + e.getMessage());
        }
    }

    private void addSubject(String id, String name) {
        String tId = this.teacher != null ? this.teacher.getIdNumber() : null;
        subjects.add(new Subject(id, name, tId));
        persist();
    }

    private void removeSelectedSubject(Subject subject) {
        if (subject == null) return;
        subjects.remove(subject);
        persist();
    }

    private void persist() {
        try {
            // Merge: keep other teachers' subjects, replace this teacher's set
            java.util.List<Subject> all = fileManager.readAll();
            String tId = this.teacher != null ? this.teacher.getIdNumber() : null;
            java.util.List<Subject> merged = new java.util.ArrayList<>();
            for (Subject s : all) {
                if (tId != null && tId.equals(s.getTeacherId())) continue; // drop old ones for this teacher
                merged.add(s);
            }
            merged.addAll(this.subjects);
            fileManager.writeAll(merged);
            view.setSubjects(this.subjects);
        } catch (Exception e) {
            view.showError("Failed to save subjects: " + e.getMessage());
        }
    }

    public SubjectController(SubjectFileManager fileManager, TeacherSubjectDashboardView view, Model.Teacher teacher) {
        // Do not pre-load unfiltered subjects; load fresh filtered list for this teacher
        this.fileManager = fileManager;
        this.view = view;
        this.teacher = teacher;

        // Wire actions
        this.view.onAddSubject(this::addSubject);
        this.view.onRemoveSubject(this::removeSelectedSubject);
        this.view.onOpenSubject(this::openSubjectDashboard);

        // Load and show per-teacher subject summaries using the summary CSV to avoid delimiter issues
        try {
            String tId = teacher != null ? teacher.getIdNumber() : null;
            FileManager.TeacherSubjectSummaryFileManager tssfm = new FileManager.TeacherSubjectSummaryFileManager(tId);
            java.util.List<String[]> summaryRows;
            try {
                summaryRows = tssfm.readAll();
            } catch (java.io.IOException ioe) {
                summaryRows = new java.util.ArrayList<>();
            }

            // If summary is empty, build it from master subjects and write it
            if (summaryRows.isEmpty()) {
                java.util.List<Subject> all = fileManager.readAll();
                this.subjects = new java.util.ArrayList<>();
                for (Subject s : all) {
                    if (tId == null || tId.equals(s.getTeacherId())) {
                        this.subjects.add(s);
                    }
                }
                summaryRows = new java.util.ArrayList<>();
                for (Subject s : this.subjects) {
                    try {
                        FileManager.SubjectMembershipFileManager sm = new FileManager.SubjectMembershipFileManager(s.getId());
                        int count = sm.loadStudentIds().size();
                        summaryRows.add(new String[]{s.getId(), s.getName(), String.valueOf(count)});
                    } catch (Exception ex) {
                        summaryRows.add(new String[]{s.getId(), s.getName(), "0"});
                    }
                }
                try { tssfm.writeAll(summaryRows); } catch (Exception ignore) {}
            }

            // Maintain a Subject list for downstream handlers (Open Subject etc.)
            this.subjects = new java.util.ArrayList<>();
            for (String[] r : summaryRows) {
                String id = (r != null && r.length > 0) ? r[0] : "";
                String name = (r != null && r.length > 1) ? r[1] : "";
                this.subjects.add(new Subject(id, name, tId));
            }

            // Show with enrollment counts in the table
            this.view.setSubjectSummaries(summaryRows);
        } catch (FileReadException e) {
            this.view.showError("Failed to load subjects: " + e.getMessage());
            this.subjects = new java.util.ArrayList<>();
            this.view.setSubjects(this.subjects);
        }

        // Set greeting in header
        this.view.setTeacherGreeting(teacher.getName());

        // Logout wiring
        this.view.addLogoutListener(e -> {
            View.LoginView loginView = new View.LoginView();
            new Controller.LoginController(loginView, Service.AuthService.getInstance());
            Utility.PageNavigation.switchViews(this.view, loginView);
        });
    }

    private void openSubjectDashboard(Subject subject) {
        if (subject == null) return;
        View.TeacherDashboardView dashView = new View.TeacherDashboardView();
        Model.Teacher effectiveTeacher = this.teacher != null ? this.teacher : new Model.Teacher(subject.getTeacherId(), "", "");
        new Controller.TeacherDashboardController(dashView, effectiveTeacher, subject);
        dashView.setTitle("Flippio - " + subject.getName() + " Quizzes");
        Utility.PageNavigation.switchViews(this.view, dashView);
    }
}
