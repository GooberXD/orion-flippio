package Controller;

import FileManager.SubjectFileManager;
import Model.Subject;
import View.TeacherSubjectDashboardView;
import Exception.FileReadException;

import java.util.ArrayList;
import java.util.List;

public class SubjectController {
    private final SubjectFileManager fileManager;
    private final TeacherSubjectDashboardView view;
    private List<Subject> subjects = new ArrayList<>();

    private Model.Teacher teacher;

    public SubjectController(SubjectFileManager fileManager, TeacherSubjectDashboardView view) {
        this.fileManager = fileManager;
        this.view = view;
        this.view.onAddSubject(this::addSubject);
        this.view.onRemoveSubject(this::removeSelectedSubject);
        this.view.onOpenSubject(this::openSubjectDashboard);
        loadSubjects();
    }

    private void loadSubjects() {
        try {
            subjects = fileManager.readAll();
            view.setSubjects(subjects);
        } catch (FileReadException e) {
            view.showError("Failed to load subjects: " + e.getMessage());
        }
    }

    private void addSubject(String id, String name) {
        String tId = this.teacher != null ? this.teacher.getIdNumber() : null;
        subjects.add(new Subject(id, name, tId));
        persist();
    }

    private void removeSelectedSubject(Subject subject) {
        if (subject == null) return;
        subjects.remove(subject);
        persist();
    }

    private void persist() {
        try {
            // Merge: keep other teachers' subjects, replace this teacher's set
            java.util.List<Subject> all = fileManager.readAll();
            String tId = this.teacher != null ? this.teacher.getIdNumber() : null;
            java.util.List<Subject> merged = new java.util.ArrayList<>();
            for (Subject s : all) {
                if (tId != null && tId.equals(s.getTeacherId())) continue; // drop old ones for this teacher
                merged.add(s);
            }
            merged.addAll(this.subjects);
            fileManager.writeAll(merged);
            view.setSubjects(this.subjects);
        } catch (Exception e) {
            view.showError("Failed to save subjects: " + e.getMessage());
        }
    }

    public SubjectController(SubjectFileManager fileManager, TeacherSubjectDashboardView view, Model.Teacher teacher) {
        this(fileManager, view);
        this.teacher = teacher;
        // Filter subjects for this teacher
        this.subjects.removeIf(s -> s.getTeacherId() != null && !s.getTeacherId().equals(teacher.getIdNumber()));
        this.view.setSubjects(this.subjects);
        // Set greeting in header
        this.view.setTeacherGreeting(teacher.getName());

        // Logout wiring
        this.view.addLogoutListener(e -> {
            View.LoginView loginView = new View.LoginView();
            new Controller.LoginController(loginView, Service.AuthService.getInstance());
            Utility.PageNavigation.switchViews(this.view, loginView);
        });
    }

    private void openSubjectDashboard(Subject subject) {
        if (subject == null) return;
        View.TeacherDashboardView dashView = new View.TeacherDashboardView();
        Model.Teacher effectiveTeacher = this.teacher != null ? this.teacher : new Model.Teacher(subject.getTeacherId(), "", "");
        new Controller.TeacherDashboardController(dashView, effectiveTeacher, subject);
        dashView.setTitle("Flippio - " + subject.getName() + " Quizzes");
        Utility.PageNavigation.switchViews(this.view, dashView);
    }
}
