package Controller;

import FileManager.QuizFileManager;
import FileManager.SubjectFileManager;
import java.awt.*;
import javax.swing.*;
import FileManager.QuizFileManager;
import FileManager.SubjectFileManager;
import View.*;
import Model.*;
import Service.*;
import Utility.*;
import Service.*;
import Utility.*;
import Exception.*;
import javax.swing.*;
import java.util.*;
import java.awt.*;

public class TeacherDashboardController {
    private TeacherDashboardView view;
    private Teacher teacher;
    private Subject subject; // optional subject context
    private ScoreService scoreService;

    public TeacherDashboardController(TeacherDashboardView view, Teacher teacher) {
        this.view = view;
        this.teacher = teacher;
        this.scoreService = new ScoreService("scores.csv");

        initController();
    }

    // Overload: with subject context (opened from Subject dashboard)
    public TeacherDashboardController(TeacherDashboardView view, Teacher teacher, Subject subject) {
        this.view = view;
        this.teacher = teacher;
        this.subject = subject;
        this.scoreService = new ScoreService("scores.csv");
        initController();
    }

    private void initController() {
        // 1. Set Welcome Text
        view.setTeacherName(teacher.getName());

        // 2. Load Subject Students and quizzes
        loadSubjectStudents();
        loadTeacherQuizzes();

        // 3. Navigation Listeners
        view.addLogoutListener(e -> {
            LoginView loginView = new LoginView();
            new LoginController(loginView, AuthService.getInstance());
            PageNavigation.switchViews(view, loginView);
        });

        view.addCreateQuizListener(e -> {
            view.dispose(); // Close dashboard
            CreateQuizView createView = new CreateQuizView();
            if (subject != null) {
                new CreateQuizController(createView, teacher, subject);
            } else {
                new CreateQuizController(createView, teacher);
            }
            createView.setVisible(true);
        });

        // 4. Ranking Listener
        view.addRefreshRankListener(e -> calculateRankings());

        // 5. Delete Quiz Listener
        view.addDeleteQuizListener(e -> deleteQuizProcess());

        // 6. Back to Subjects
        view.addBackListener(e -> {
            TeacherSubjectDashboardView subjView = new TeacherSubjectDashboardView();
            SubjectFileManager sfm = new SubjectFileManager("subject_" + teacher.getIdNumber() + ".csv");
            new SubjectController(sfm, subjView, teacher);
            PageNavigation.switchViews(view, subjView);
        });

        // 7. Add Student to Subject
        view.addAddStudentToSubjectListener(e -> addStudentToSubject());

        // 8. Quiz button pressed -> show modal with Modify/Turn In or performance
        // Modal is invoked from addQuizButton listeners created in loadTeacherQuizzes
    }

    private void loadTeacherQuizzes() {
        try {
            QuizFileManager qfm = new QuizFileManager("quizzes.txt");
            java.util.List<Quiz> all = qfm.load();
            java.util.List<String> names = new java.util.ArrayList<>();
            for (Quiz q : all) {
                boolean ownerOk = (q.getTeacherId() != null && q.getTeacherId().equals(teacher.getIdNumber()));
                boolean subjectOk = (subject == null || (q.getSubjectId() != null && q.getSubjectId().equals(subject.getId())));
                if (ownerOk && subjectOk) names.add(q.getQuizName());
            }
            // Populate buttons with proper listeners
            view.clearQuizButtons();
            for (String name : names) {
                view.addQuizButton(name, e -> showQuizModal(name));
            }
        } catch (Exception ignore) {
            view.clearQuizButtons();
        }
    }

    private void showQuizModal(String quizName) {
        // If quiz is published, show performance directly
        try {
            QuizFileManager qfm = new QuizFileManager("quizzes.txt");
            java.util.List<Quiz> all = qfm.load();
            for (Quiz q : all) {
                if (q.getQuizName().equalsIgnoreCase(quizName)) {
                    if (q.isPublished()) { showPerformanceDialog(quizName); return; }
                    break;
                }
            }
        } catch (Exception ignore) {}

        JDialog dialog = new JDialog(view, quizName, true);
        JPanel panel = new JPanel(new BorderLayout(10,10));
        panel.setBorder(BorderFactory.createEmptyBorder(15,15,15,15));
        JLabel info = new JLabel("Quiz: " + quizName);
        info.setHorizontalAlignment(SwingConstants.CENTER);

        JButton modifyBtn = new JButton("Modify");
        modifyBtn.setPreferredSize(new Dimension(120, 36));
        modifyBtn.setBackground(new Color(108, 117, 125)); // secondary gray
        modifyBtn.setForeground(Color.WHITE);
        modifyBtn.addActionListener(e -> {
            dialog.dispose();
            // Dispose dashboard to avoid duplication and enable fresh reload after edit
            view.dispose();
            CreateQuizView editView = new CreateQuizView();
            if (subject != null) {
                new CreateQuizController(editView, teacher, subject, quizName);
            } else {
                new CreateQuizController(editView, teacher, null, quizName);
            }
            editView.setVisible(true);
        });

        JButton turnInBtn = new JButton("Turn In");
        turnInBtn.setPreferredSize(new Dimension(120, 36));
        turnInBtn.setBackground(new Color(40, 167, 69)); // green
        turnInBtn.setForeground(Color.WHITE);
        turnInBtn.addActionListener(e -> {
            try {
                QuizFileManager qfm = new QuizFileManager("quizzes.txt");
                qfm.publishQuiz(quizName);
                JOptionPane.showMessageDialog(view, "Quiz published for students.");
                loadTeacherQuizzes();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(view, "Failed to publish: " + ex.getMessage());
            } finally {
                dialog.dispose();
            }
        });

        JPanel south = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        // Rename button
        JButton renameBtn = new JButton("Rename");
        renameBtn.setPreferredSize(new Dimension(120,36));
        renameBtn.addActionListener(ev -> {
            String newName = JOptionPane.showInputDialog(view, "Enter new quiz name:", quizName);
            if (newName == null || newName.trim().isEmpty()) return;
            int confirm = JOptionPane.showConfirmDialog(view,
                    "This will also update existing score records. Proceed?",
                    "Confirm Rename",
                    JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;
            try {
                QuizFileManager qfm = new QuizFileManager("quizzes.txt");
                qfm.renameQuiz(quizName, newName.trim());
                // Also rename scores entries
                ScoreService ss = new ScoreService("scores.csv");
                ss.renameQuizScores(quizName, newName.trim());
                JOptionPane.showMessageDialog(view, "Quiz renamed and scores updated.");
                dialog.dispose();
                loadTeacherQuizzes();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(view, "Rename failed: " + ex.getMessage());
            }
        });

        south.add(modifyBtn);
        south.add(renameBtn);
        south.add(turnInBtn);
        panel.add(info, BorderLayout.CENTER);
        panel.add(south, BorderLayout.SOUTH);
        dialog.setContentPane(panel);
        dialog.setSize(360, 180);
        dialog.setLocationRelativeTo(view);
        dialog.setVisible(true);
    }

    // Show performance dialog when quiz is published
    private void showPerformanceDialog(String quizName) {
        // Determine subject id for the quiz
        String subjectId = null;
        try {
            QuizFileManager qfm = new QuizFileManager("quizzes.txt");
            java.util.List<Quiz> all = qfm.load();
            for (Quiz q : all) {
                if (q.getQuizName().equalsIgnoreCase(quizName)) { subjectId = q.getSubjectId(); break; }
            }
        } catch (Exception ignore) {}

        // Build table of student performances for this quiz, filtered by subject membership
        java.util.List<QuizResult> results = scoreService.getAllResults();
        java.util.List<QuizResult> filtered = new java.util.ArrayList<>();
        java.util.Set<String> allowedIds = new java.util.HashSet<>();
        if (subjectId != null) {
            try {
                FileManager.SubjectMembershipFileManager sm = new FileManager.SubjectMembershipFileManager(subjectId);
                allowedIds.addAll(sm.loadStudentIds());
            } catch (Exception ignore) {}
        }
        for (QuizResult r : results) {
            boolean nameMatch = r.getQuizName().equalsIgnoreCase(quizName);
            boolean memberOk = (allowedIds.isEmpty() || allowedIds.contains(r.getStudentId()));
            if (nameMatch && memberOk) filtered.add(r);
        }

        String[] cols = {"Student ID", "Score", "Total", "Status"};
        javax.swing.table.DefaultTableModel model = new javax.swing.table.DefaultTableModel(cols, 0);
        for (QuizResult r : filtered) {
            String status = (r.getScore() / r.getTotalItems() >= 0.5) ? "PASS" : "FAIL";
            model.addRow(new Object[]{r.getStudentId(), r.getScore(), r.getTotalItems(), status});
        }
        JTable table = new JTable(model);
        table.setRowHeight(22);
        // Color status column
        table.getColumnModel().getColumn(3).setCellRenderer(new javax.swing.table.DefaultTableCellRenderer(){
            @Override protected void setValue(Object value){
                super.setValue(value);
                if ("PASS".equals(value)) setForeground(new Color(40,167,69));
                else setForeground(new Color(200,50,50));
            }
        });
        JScrollPane scroll = new JScrollPane(table);
        JOptionPane.showMessageDialog(view, scroll, "Student Performance - " + quizName, JOptionPane.INFORMATION_MESSAGE);
    }

    // --- LOGIC: DELETE QUIZ AND RECORDS ---
    private void deleteQuizProcess() {
        // 1. Ask user for the Quiz Name
        String quizName = JOptionPane.showInputDialog(view, "Enter the exact name of the Quiz to delete:");

        if (quizName != null && !quizName.trim().isEmpty()) {
            // Verify ownership/subject before confirming
            boolean allowed = false;
            try {
                QuizFileManager qfm = new QuizFileManager("quizzes.txt");
                for (Quiz q : qfm.load()) {
                    boolean ownerOk = (q.getTeacherId() != null && q.getTeacherId().equals(teacher.getIdNumber()));
                    boolean subjectOk = (subject == null || (q.getSubjectId() != null && q.getSubjectId().equals(subject.getId())));
                    if (q.getQuizName().equalsIgnoreCase(quizName.trim()) && ownerOk && subjectOk) {
                        allowed = true; break;
                    }
                }
            } catch (Exception ignore) {}

            if (!allowed) {
                JOptionPane.showMessageDialog(view, "You can only delete your own quiz in this context.");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(view,
                    "Are you sure you want to delete '" + quizName + "'?\nThis will delete the quiz AND all student results associated with it.\nThis cannot be undone.",
                    "Confirm Delete",
                    JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    // A. Delete the Quiz Definition (quizzes.txt)
                    QuizFileManager quizManager = new QuizFileManager("quizzes.txt");
                    quizManager.deleteQuiz(quizName.trim());

                    // B. Delete Related Scores (scores.csv)
                    scoreService.deleteScoresByQuizName(quizName.trim());

                    // C. Refresh the Dashboard UI
                    calculateRankings(); // Recalculate ranks (averages might change)

                    JOptionPane.showMessageDialog(view, "Quiz and related records deleted successfully.");

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(view, "Error: " + ex.getMessage());
                }
            }
        }
    }

    // Removed loadStudentScores usage since Student Performance tab is removed.

    private void loadSubjectStudents() {
        try {
            if (subject == null) { view.setStudents(java.util.Collections.emptyList()); return; }
            FileManager.SubjectMembershipFileManager sm = new FileManager.SubjectMembershipFileManager(subject.getId());
            java.util.List<String> ids = sm.loadStudentIds();
            // Build Student objects for display using students.csv only to resolve names
            StudentService studentService = new StudentService("students.csv");
            java.util.List<Student> all = studentService.getAllStudents();
            java.util.List<Student> members = new java.util.ArrayList<>();
            for (String id : ids) {
                for (Student s : all) {
                    if (s.getIdNumber().equals(id)) { members.add(s); break; }
                }
            }
            view.setStudents(members);
        } catch (Exception ignore) {
            view.setStudents(java.util.Collections.emptyList());
        }
    }

    private void addStudentToSubject() {
        if (subject == null) return;
        String id = javax.swing.JOptionPane.showInputDialog(view, "Enter existing Student ID to add:");
        if (id == null || id.trim().isEmpty()) return;
        try {
            // Verify student exists
            StudentService studentService = new StudentService("students.csv");
            java.util.List<Student> all = studentService.getAllStudents();
            boolean exists = all.stream().anyMatch(s -> s.getIdNumber().equals(id.trim()));
            if (!exists) {
                javax.swing.JOptionPane.showMessageDialog(view, "Student ID not found.");
                return;
            }
            // Add to subject membership
            FileManager.SubjectMembershipFileManager sm = new FileManager.SubjectMembershipFileManager(subject.getId());
            sm.addStudentId(id.trim());
            loadSubjectStudents();
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(view, "Failed to add student: " + ex.getMessage());
        }
    }

    private void calculateRankings() {
        try {
            view.clearRankings();
            StudentService studentService = new StudentService("students.csv");
            java.util.List<Student> students = studentService.getAllStudents();

            if (students.isEmpty()) {
                // If no students, just return, don't throw error to allow empty state
                return;
            }

            // Sort by Average Score (Descending)
            students.sort((s1, s2) -> Double.compare(s2.getAverageScore(), s1.getAverageScore()));

            int rank = 1;
            for (Student s : students) {
                view.addRankingRow(rank++, s.getName(), s.getAverageScore());
            }

        } catch (Exception e) {
            // Ignore file errors during refresh
        }
    }
}