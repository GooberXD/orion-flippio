package Controller;

import Model.*;
import View.*;
import Service.*;
import FileManager.*;
import Exception.*; // Custom Exceptions
import java.awt.Dimension;
import java.util.*;
import javax.swing.*;
import FileManager.SubjectMembershipFileManager;

public class StudentDashboardController {
    private StudentDashboardView view;
    private Student student;

    public StudentDashboardController(StudentDashboardView view, Student student) {
        this.view = view;
        this.student = student;

        initDashboard();
    }

    private void initDashboard() {
        view.setStudentName(student.getName());
        loadPerformanceData();
        loadQuizButtons();
        view.addLogoutListener(e -> logout());
        view.addDownloadListener(e -> downloadReport());
    }

    private void loadPerformanceData() {
        // Load data from student-specific CSV file (student_<id>.csv)
        // Each row format: subject|quiz|percentage|status
        double percentageSum = 0.0;
        int entries = 0;

        try {
            StudentPerformanceFileManager perfFm = new StudentPerformanceFileManager(student.getIdNumber());
            java.util.List<String[]> rows = perfFm.readAll();

            for (String[] row : rows) {
                if (row.length >= 3) {
                    String quizName = row[1];
                    double percentage = Double.parseDouble(row[2]);
                    
                    // Get actual quiz to find total questions
                    QuizFileManager qfm = new QuizFileManager("quizzes.txt");
                    int totalQuestions = 0;
                    try {
                        for (Quiz q : qfm.load()) {
                            if (q.getQuizName().equalsIgnoreCase(quizName)) {
                                totalQuestions = q.getQuestions().size();
                                break;
                            }
                        }
                    } catch (Exception ignore) {}
                    
                    // Convert percentage back to actual score
                    double score = (totalQuestions == 0) ? 0.0 : (percentage / 100.0) * totalQuestions;
                    String status = (percentage >= 50.0) ? "PASSED" : "FAILED";
                    view.addResultRow(quizName, score, (double) totalQuestions, status);
                    percentageSum += percentage;
                    entries++;
                }
            }
        } catch (Exception ex) {
            // Ignore and fallback below
        }

        if (entries == 0) {
            // Fallback to in-memory results if no CSV entries yet
            java.util.List<Double> results = student.getQuizResults();
            int count = 1;
            for (Double score : results) {
                String quizName = "Quiz Attempt " + count;
                // Assume 10 items default for legacy results to estimate %
                double percent = (score / 10.0) * 100.0;
                String status = (percent >= 50.0) ? "PASSED" : "FAILED";
                view.addResultRow(quizName, score, 10.0, status);
                percentageSum += percent;
                entries++;
                count++;
            }
        }

        double averagePercent = (entries == 0) ? 0.0 : (percentageSum / entries);
        view.updateAverageScore(averagePercent);
    }

    private void loadQuizButtons() {
        view.clearQuizButtons();
        QuizFileManager quizManager = new QuizFileManager("quizzes.txt");
        List<Quiz> availableQuizzes = new ArrayList<>();

        try {
            availableQuizzes = quizManager.load();
        } catch (Exception e) {
            System.err.println("Could not load quizzes: " + e.getMessage());
        }

        // Show only quizzes that are published by teachers AND belong to subjects the student is enrolled in
        java.util.List<Quiz> visibleQuizzes = new java.util.ArrayList<>();
        // Build enrolled subject set
        java.util.Set<String> enrolledSubjectIds = new java.util.HashSet<>();
        try {
            // If teacher-managed subjects exist, membership files are named subject_<subjectId>.csv
            // We'll scan quizzes to know candidate subject IDs, then check membership files
            java.util.Set<String> candidateSubjectIds = new java.util.HashSet<>();
            for (Quiz q : availableQuizzes) {
                if (q != null && q.getSubjectId() != null && !q.getSubjectId().isEmpty()) {
                    candidateSubjectIds.add(q.getSubjectId());
                }
            }
            for (String sid : candidateSubjectIds) {
                try {
                    SubjectMembershipFileManager sm = new SubjectMembershipFileManager(sid);
                    java.util.List<String> members = sm.loadStudentIds();
                    if (members.stream().anyMatch(id -> id.equals(student.getIdNumber()))) {
                        enrolledSubjectIds.add(sid);
                    }
                } catch (Exception ignore) {}
            }
        } catch (Exception ignore) {}

        for (Quiz q : availableQuizzes) {
            if (q != null && q.isPublished()) {
                String sid = q.getSubjectId();
                // If quiz has a subjectId, require enrollment; if not, include for backward compatibility
                if (sid == null || sid.isEmpty() || enrolledSubjectIds.contains(sid)) {
                    visibleQuizzes.add(q);
                }
            }
        }

        if (!visibleQuizzes.isEmpty()) {
            for (Quiz q : visibleQuizzes) {
                boolean taken = hasTakenQuiz(q);
                String label = taken ? (q.getQuizName() + " (Taken)") : q.getQuizName();
                view.addQuizButton(label, e -> launchQuiz(q));
            }
            return;
        }

        // If no published/enrolled quizzes exist, show an informational dialog instead of dummy topics
        JOptionPane.showMessageDialog(view, "No available quizzes have been published for your subjects yet.");
    }

    private void launchQuiz(Quiz quiz) {
        // Block retakes: a quiz can only be taken once per student
        if (hasTakenQuiz(quiz)) {
            JOptionPane.showMessageDialog(view, "You have already taken this quiz.");
            return;
        }
        QuizTakingView quizView = new QuizTakingView();
        new QuizTakingController(quizView, quiz, student);
        view.dispose();
        quizView.setVisible(true);
    }

    // Check student_<id>.csv to see if this quiz already has a recorded attempt
    private boolean hasTakenQuiz(Quiz quiz) {
        try {
            StudentPerformanceFileManager perfFm = new StudentPerformanceFileManager(student.getIdNumber());
            java.util.List<String[]> rows = perfFm.readAll();
            String targetName = quiz.getQuizName();
            String targetSubject = quiz.getSubjectId() == null ? "" : quiz.getSubjectId();
            for (String[] r : rows) {
                if (r.length >= 2) {
                    String recordedSubject = (r.length >= 1 && r[0] != null) ? r[0] : "";
                    String recordedQuiz = r[1] == null ? "" : r[1];
                    boolean nameMatch = recordedQuiz.equalsIgnoreCase(targetName);
                    boolean subjectMatch = targetSubject.isEmpty() || recordedSubject.equalsIgnoreCase(targetSubject) || recordedSubject.isEmpty();
                    if (nameMatch && subjectMatch) {
                        return true;
                    }
                }
            }
        } catch (Exception ignore) { }
        return false;
    }

    // Removed default topic fallback to avoid showing non-existent quizzes

    // --- MODIFIED METHOD: DOWNLOAD AND DISPLAY ---
    private void downloadReport() {
        // 1. Build the Report Content in Memory (from student_<id>.csv)
        StringBuilder reportBuilder = new StringBuilder();

        // Read from student performance CSV (subject|quiz|percentage|status)
        double percentageSum = 0.0;
        int quizCount = 0;
        java.util.List<String> quizLines = new java.util.ArrayList<>();
        
        try {
            StudentPerformanceFileManager perfFm = new StudentPerformanceFileManager(student.getIdNumber());
            java.util.List<String[]> rows = perfFm.readAll();
            
            for (String[] row : rows) {
                if (row.length >= 3) {
                    String quizName = row[1];
                    double percentage = Double.parseDouble(row[2]);
                    
                    // Get actual quiz to find total questions
                    QuizFileManager qfm = new QuizFileManager("quizzes.txt");
                    int totalQuestions = 0;
                    try {
                        for (Quiz q : qfm.load()) {
                            if (q.getQuizName().equalsIgnoreCase(quizName)) {
                                totalQuestions = q.getQuestions().size();
                                break;
                            }
                        }
                    } catch (Exception ignore) {}
                    
                    // Convert percentage back to actual score
                    double score = (totalQuestions == 0) ? 0.0 : (percentage / 100.0) * totalQuestions;
                    String status = (percentage >= 50.0) ? "PASSED" : "FAILED";
                    
                    quizLines.add(String.format("- Quiz: %s | Score: %.1f / %d | Status: %s",
                        quizName, score, totalQuestions, status));
                    percentageSum += percentage;
                    quizCount++;
                }
            }
        } catch (Exception ex) {
            System.err.println("Failed to read performance data: " + ex.getMessage());
        }

        double avgPercent = (quizCount == 0) ? 0.0 : (percentageSum / quizCount);

        reportBuilder.append("FLIPPIO STUDENT REPORT\n");
        reportBuilder.append("----------------------\n");
        reportBuilder.append("Student: ").append(student.getName()).append("\n");
        reportBuilder.append("ID: ").append(student.getIdNumber()).append("\n");
        reportBuilder.append("Average Performance: ").append(String.format("%.2f%%", avgPercent)).append("\n");
        reportBuilder.append("----------------------\n");
        reportBuilder.append("Quiz History:\n");

        if (!quizLines.isEmpty()) {
            for (String line : quizLines) {
                reportBuilder.append(line).append("\n");
            }
        } else {
            reportBuilder.append("No quizzes completed yet.\n");
        }

        String reportContent = reportBuilder.toString();
        String fileName = "Report_" + student.getName().replaceAll(" ", "_") + ".txt";

        // 2. Save to File
        try (java.io.BufferedWriter writer = new java.io.BufferedWriter(new java.io.FileWriter(fileName))) {
            writer.write(reportContent);

            // Success Message
            JOptionPane.showMessageDialog(view, "Report downloaded successfully to: " + fileName);

            // 3. SHOW DIALOG (GUI Output)
            showReportDialog(reportContent);

        } catch (java.io.IOException e) {
            // Throw Custom Exception
            JOptionPane.showMessageDialog(view, new FileWriteException("Could not save report: " + e.getMessage()).getMessage());
        }
    }

    // Helper to show the report in a scrollable text area
    private void showReportDialog(String content) {
        JTextArea textArea = new JTextArea(content);
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 13));

        // Add vertical padding at both ends of content
        textArea.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JScrollPane scrollPane = new JScrollPane(textArea);
        // Increase width so PASS/FAILED stays on one line
        scrollPane.setPreferredSize(new Dimension(600, 450));

        JOptionPane.showMessageDialog(view, scrollPane, "Grade Report Preview", JOptionPane.INFORMATION_MESSAGE);
    }

    private void logout() {
        view.dispose();
        LoginView loginView = new LoginView();
        AuthService auth = AuthService.getInstance();
        new LoginController(loginView, auth);
        loginView.setVisible(true);
    }
}