package Service;

import FileManager.ScoreFileManager;
import Model.QuizResult;
import java.util.List;

public class ScoreService {
    private ScoreFileManager fileManager;

    public ScoreService(String filename) {
        this.fileManager = new ScoreFileManager(filename);
    }

    public List<QuizResult> getAllResults() {
        try {
            return fileManager.load();
        } catch (Exception e) {
            return new java.util.ArrayList<>();
        }
    }

    // --- THIS IS THE MISSING METHOD CAUSING YOUR ERROR ---
    public void saveResult(QuizResult result) throws Exception {
        fileManager.save(result);
    }

    // Delete method (from previous step)
    public void deleteScoresByQuizName(String quizName) throws Exception {
        List<QuizResult> allResults = getAllResults();
        allResults.removeIf(r -> r.getQuizName().equalsIgnoreCase(quizName));
        fileManager.overwrite(allResults);
    }

    // Rename all score entries for a quiz from oldName to newName
    public void renameQuizScores(String oldName, String newName) throws Exception {
        if (newName == null || newName.trim().isEmpty()) throw new Exception("New quiz name cannot be empty.");
        List<QuizResult> all = getAllResults();
        for (QuizResult r : all) {
            if (r.getQuizName().equalsIgnoreCase(oldName)) {
                // Create a new QuizResult with updated name but same data
                // Or mutate if getters/setters exist; assuming immutable, rebuild
                // However QuizResult fields may have setters; try via reflection of constructor used
                // Safer: replace element
                QuizResult updated = new QuizResult(r.getStudentId(), newName.trim(), r.getScore(), r.getTotalItems());
                int idx = all.indexOf(r);
                all.set(idx, updated);
            }
        }
        fileManager.overwrite(all);
    }
}