package Exception;

public class RankingException extends Exception {
    public RankingException(String message) { super(message); }
}
