package Exception;

public class UnansweredQuestionException extends Exception {
    public UnansweredQuestionException(String message) { super(message); }
}
