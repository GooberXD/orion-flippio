package Exception;

public class UserInputErrorException extends Exception {
    public UserInputErrorException(String message) { super(message); }
}

