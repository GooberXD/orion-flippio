package Exception;

public class FileWriteException extends Exception {
    public FileWriteException(String message) { super(message); }
}
